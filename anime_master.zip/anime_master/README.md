# Anime Master (minimal starter)

This is a minimal Flutter starter project to upload to build services (Codemagic, etc.).

Run `flutter pub get` then `flutter build apk` on a machine with Flutter & Android SDK installed.
